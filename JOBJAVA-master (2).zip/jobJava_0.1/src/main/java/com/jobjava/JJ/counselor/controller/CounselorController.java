package com.jobjava.JJ.counselor.controller;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.jobjava.JJ.counselor.vo.CriteriaVO;

public interface CounselorController {
	public ModelAndView counselor(HttpServletRequest request, HttpServletResponse response) throws Exception;
	// ���� ������ ������ ȣ��
	public ModelAndView jobregForm(HttpServletRequest request, HttpServletResponse response) throws Exception;
	public ModelAndView addJob(@RequestParam HashMap<String, String> jobregVO,HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	
	
	// ���� ���е�� ������ ȣ�� 
	public ModelAndView uniregForm(HttpServletRequest request, HttpServletResponse response) throws Exception;
	public String adduni(@RequestParam HashMap<String, String> uniregVO,HttpServletRequest request, HttpServletResponse response) throws Exception;

	// ���簡 ����� ���� ��� �Խ���
	public ModelAndView uniregList(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	// ���� ��� ��â ��ȸ
	public ModelAndView uniregView(HttpServletRequest request, HttpServletResponse response,
	          @RequestParam String unibno) throws Exception;
	
	// �������� ����
	
	public ResponseEntity modifyuniregState(@RequestParam HashMap<String, String> unireg, HttpServletRequest request, 
			HttpServletResponse response) throws Exception;
	
	public String regcheck(@RequestParam HashMap<String, String> uniregVO,HttpServletRequest request, HttpServletResponse response) throws Exception; 

	public ModelAndView addUni(@RequestParam HashMap<String, String> UniregVO, HttpServletRequest request,
			HttpServletResponse response) throws Exception;

	public ModelAndView attendance(HttpServletRequest request, HttpServletResponse response) throws Exception;

	public ModelAndView commuteCheck(@RequestParam HashMap<String, String> commuteDate, HttpServletRequest request,
			HttpServletResponse response) throws Exception;
	
//	public ModelAndView boardList(CriteriaVO cri, Model model, HttpServletRequest request, HttpServletResponse response)
//			throws Exception;
	
	public ModelAndView companyDetail(HttpServletRequest request, HttpServletResponse response,
			@RequestParam("regiNO") String regiNO) throws Exception;

}
