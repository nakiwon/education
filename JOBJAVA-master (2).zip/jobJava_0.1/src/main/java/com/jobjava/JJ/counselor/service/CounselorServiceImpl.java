package com.jobjava.JJ.counselor.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jobjava.JJ.counselor.dao.CounselorDAO;
import com.jobjava.JJ.counselor.vo.CriteriaVO;
import com.jobjava.JJ.counselor.vo.JobregVO;
import com.jobjava.JJ.counselor.vo.UniregVO;
import com.jobjava.JJ.member.dao.memberDAO;

@Service("CounselorService")
public class CounselorServiceImpl implements CounselorService {
	@Autowired
	private SqlSessionTemplate sqlSession;
	
	public List<HashMap<String, String>> JobList() {
		List<HashMap<String, String>> counselor = new ArrayList<HashMap<String, String>>();
		CounselorDAO dao = sqlSession.getMapper(CounselorDAO.class);
		counselor.add(dao.JobDao());
		counselor.add(dao.JobDao2());
//		System.out.println(counselor);
		return counselor;
	}
	/*
	 * public List<Map<String, Object>> boardList(CriteriaVO cri) { CounselorDAO dao
	 * = sqlSession.getMapper(CounselorDAO.class); return dao.boardList(cri); }
	 */
	

	// -- //

	public void insertJob(HashMap<String, String> job) {
		CounselorDAO dao = sqlSession.getMapper(CounselorDAO.class);
		job.put("JOB_NO", dao.selectNewJobID(job));
//		dao.insertNewJob(job);
		
	}

	public JobregVO selectLegister(JobregVO jobregVO) {
		CounselorDAO dao = sqlSession.getMapper(CounselorDAO.class);
		JobregVO jobregvo = new JobregVO();
		return jobregvo;
	}
	
	public void addJob(HashMap<String, String> jobregVO) {
		CounselorDAO dao = sqlSession.getMapper(CounselorDAO.class);
		dao.insertNewJob(jobregVO);
	}
	
	
	// -- //
	
	public void insertUni(HashMap<String, String> uni) {
		CounselorDAO dao = sqlSession.getMapper(CounselorDAO.class);
		uni.put("UNI_B_NO", dao.selectUniID(uni));
//		dao.insertNewJob(job);
		
	}
	
	public UniregVO selectLegister(UniregVO uniregVO) {
		CounselorDAO dao = sqlSession.getMapper(CounselorDAO.class);
		UniregVO uniregVO1 = new UniregVO();
		return uniregVO1;
	}
	
	public void adduni(HashMap<String, String> uniregVO) {
		CounselorDAO dao = sqlSession.getMapper(CounselorDAO.class);
		dao.insertNewUni(uniregVO);
	}
	
	public List<HashMap<String, String>> JobList2() {
		// ����Ʈ�� �������� ��Ʈ�� Ÿ���̴�.
		List<HashMap<String, String>> counselor1 = new ArrayList<HashMap<String, String>>();
		//
		CounselorDAO dao = sqlSession.getMapper(CounselorDAO.class);
		// �̸��� dao�� �ϰڴ�. sql�� �����͸� �������ڴ�.(���?)
		counselor1 = dao.JobDao3();
		// ����Ʈ Ÿ������ JobDao3�������ڴ�.
		System.out.println(counselor1);
		return counselor1;
		// ��Ʈ�ѷ��� ���ڴ�.
	}
	
	@Override
	public List<HashMap<String, String>> attendancelist() {
		List<HashMap<String, String>> attendanceCheck = new ArrayList<HashMap<String, String>>();
		CounselorDAO dao = sqlSession.getMapper(CounselorDAO.class);
		attendanceCheck = dao.attendanceDao();
		System.out.println(attendanceCheck);
		return attendanceCheck;
	}
	
	@Override
	public List<HashMap<String, String>> commutelist(HashMap<String, String> commuteDate) {
		List<HashMap<String, String>> commuteController = new ArrayList<HashMap<String, String>>();
		CounselorDAO dao = sqlSession.getMapper(CounselorDAO.class);
		commuteController = dao.commuteDao(commuteDate);
		System.out.println(commuteController);
		return commuteController;
	}

	// ���б� ��� ���
	@Override
	public List<UniregVO> uniList() throws Exception {
		CounselorDAO dao = sqlSession.getMapper(CounselorDAO.class);
		return dao.uniList();
	}
	
	
	@Override
	   public UniregVO selectProgram(String unibno)throws Exception {
	      CounselorDAO dao = sqlSession.getMapper(CounselorDAO.class);
	      return dao.selectProgram(unibno);
	   }


	@Override
	public void modifyuniregState(HashMap<String, String> uniregVO) {
		CounselorDAO dao = sqlSession.getMapper(CounselorDAO.class);
		dao.updatePermissionState(uniregVO);
	}


	@Override
	public void regcheck(HashMap<String, String> uniregVO) {
		CounselorDAO dao = sqlSession.getMapper(CounselorDAO.class);

	}
	

	@Override
	public void addUni(HashMap<String, String> UniregVO) {
		// TODO Auto-generated method stub
		
	}


}
