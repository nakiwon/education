package com.jobjava.JJ.main.dao;

public interface MainDAO {
	public void mnLog(String mnName);
}