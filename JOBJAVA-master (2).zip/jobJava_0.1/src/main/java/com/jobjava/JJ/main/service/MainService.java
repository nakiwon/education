package com.jobjava.JJ.main.service;


public interface MainService {
	public void mnLog(String mnName);

}
